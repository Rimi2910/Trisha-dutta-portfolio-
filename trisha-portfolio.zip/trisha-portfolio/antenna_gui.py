import tkinter as tk
from tkinter import messagebox
import numpy as np
import matplotlib.pyplot as plt

# Function to calculate radiation pattern
def get_radiation_pattern(antenna_type, theta):
    if antenna_type == 'Isotropic':
        return np.ones_like(theta)
    elif antenna_type == 'Dipole':
        return np.abs(np.sin(theta))
    elif antenna_type == 'Cardioid':
        return 1 + np.cos(theta)
    elif antenna_type == 'Parabolic':
        return np.exp(-((theta - np.pi) ** 2) / 0.1)
    else:
        return np.zeros_like(theta)

# Function to plot selected antenna patterns
def plot_selected_patterns(selected_antennas):
    theta = np.linspace(0, 2 * np.pi, 360)
    count = len(selected_antennas)

    if count == 0:
        messagebox.showwarning("No Selection", "Please select at least one antenna type.")
        return

    # Create subplots for each selected antenna
    fig, axs = plt.subplots(1, count, subplot_kw={'projection': 'polar'}, figsize=(5 * count, 4))

    # If only one is selected, axs is not a list, so make it a list
    if count == 1:
        axs = [axs]

    for ax, antenna in zip(axs, selected_antennas):
        r = get_radiation_pattern(antenna, theta)
        ax.plot(theta, r, color='navy')
        ax.fill(theta, r, alpha=0.3, color='skyblue')
        ax.set_title(f"{antenna} Pattern", va='bottom', fontsize=12)
        ax.grid(True)

    plt.tight_layout()
    plt.show()

# Function to launch the GUI
def create_gui():
    # Create main window
    window = tk.Tk()
    window.title("Antenna Radiation Pattern Visualizer")
    window.geometry("400x300")
    window.configure(bg="#f5f5f5")

    tk.Label(window, text="Select Antenna Types:", font=("Helvetica", 14), bg="#f5f5f5").pack(pady=10)

    # Antenna options with checkboxes
    antenna_types = ['Isotropic', 'Dipole', 'Cardioid', 'Parabolic']
    checkbox_vars = {}

    for antenna in antenna_types:
        var = tk.IntVar()
        cb = tk.Checkbutton(window, text=antenna, variable=var, font=("Helvetica", 12), bg="#f5f5f5")
        cb.pack(anchor='w', padx=30)
        checkbox_vars[antenna] = var

    # Button to plot selected patterns
    def on_plot():
        selected = [name for name, var in checkbox_vars.items() if var.get() == 1]
        plot_selected_patterns(selected)

    tk.Button(
        window,
        text="Plot Selected Patterns",
        command=on_plot,
        font=("Helvetica", 12),
        bg="#007acc",
        fg="white",
        padx=10,
        pady=5
    ).pack(pady=20)

    window.mainloop()

# Run the GUI app
if __name__ == "__main__":
    create_gui()
